/// <reference types="Cypress" />
import CredLoginElements from '../../elements/WAElements/WALoginElements'
const credLoginElements = new CredLoginElements
const url = Cypress.config("testeWaProject")

class LoginPage {
    // Acessa o site do Credenciamento e acessar a funcionalidade de login
    acessarSite() {
        cy.visit(url)
    }
    // Preenche usuario e senha valido
    preencherUsuarioeSenha(email, senha) { 
        cy.get(credLoginElements.emailInput()).type(email);  
        cy.get(credLoginElements.senhaInput()).type(senha).type('{enter}'); 
    }     
    
    preencherUsuarioeSenhaValido() { 
        cy.get(credLoginElements.emailInput()).type('admin');  
        cy.get(credLoginElements.senhaInput()).type('senha@1233').type('{enter}'); 
    }   
    // Valida as mensagens apresentadas na funcionalidade de Login 
    validarMensagensLogin(mensagem) {
        cy.contains(mensagem);
    }
}
export default LoginPage;


