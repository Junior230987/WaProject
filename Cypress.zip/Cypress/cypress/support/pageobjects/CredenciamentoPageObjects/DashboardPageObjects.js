/// <reference types="Cypress" />
import PortalUsuarioElements from '../../elements/WAElements/PortalUsuarioElements'
const portalUsuarioElements = new PortalUsuarioElements

class Dashboard { 
    validarPerfil(tipoDeAcesso) {
        cy.contains(tipoDeAcesso)
    }   
}
export default Dashboard;
