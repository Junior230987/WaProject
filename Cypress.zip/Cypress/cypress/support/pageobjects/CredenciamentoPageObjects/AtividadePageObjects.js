/// <reference types="Cypress" />
import CredLoginElements from '../../elements/WAElements/WALoginElements'
import ManterAtividadeElements from '../../elements/WAElements/ManterAtividadeElements'
const manteratividadeelements = new ManterAtividadeElements
const credLoginElements = new CredLoginElements
const url = Cypress.config("testeWaProject")
const d = new Date();

class AtividadePage {
    // Acessa o site do Credenciamento e acessar a funcionalidade de login
    preencherAtividade() {
        cy.get(manteratividadeelements.registraratividade()).click();
        cy.get('.MuiAutocomplete-popupIndicator > .MuiIconButton-label > .MuiSvgIcon-root').click()
        cy.contains('teste123').click()
        cy.get(manteratividadeelements.data()).should('not.null');
        cy.get(manteratividadeelements.horainicio()).clear().type('08:00');
        cy.get(manteratividadeelements.horafim()).clear().type('08:10');
        cy.get(manteratividadeelements.observacoes()).type('Teste Junior');
        //cy.get(manteratividadeelements.botaocancelar()).click();
        cy.get(manteratividadeelements.botaoregistraratividade()).click();
        cy.get(manteratividadeelements.encerrarAtividade()).click()
    }
    // Preenche usuario e senha valido
    preencherUsuarioeSenha(email, senha) {
        cy.get(WALoginElements.emailInput()).type(email);
        cy.get(WALoginElements.senhaInput()).type(senha).type('{enter}');
    }
    // Valida as mensagens apresentadas na funcionalidade de Login 
    validarMensagensLogin(mensagem) {
        cy.contains(mensagem);
    }
    validarMensagensAtividades() {
        cy.contains('Atividade cadastrada com sucesso').should('be.visible')
    }
}
export default AtividadePage;


