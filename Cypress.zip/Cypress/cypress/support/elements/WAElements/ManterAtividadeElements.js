class ManterAtividadeElements {
//Locators do registrar atividade 

    registraratividade = () => { return '.MuiBox-root > .MuiButtonBase-root > .MuiButton-label'}
    setabotaoprojetos = () => { return '.MuiAutocomplete-popupIndicator > .MuiIconButton-label > .MuiSvgIcon-root > path'}  
    data = () => { return '.MuiInputAdornment-root > .MuiSvgIcon-root'}
    horainicio = () => { return '.MuiGrid-container > :nth-child(1) > .MuiFormControl-root > .MuiInputBase-root > .MuiInputBase-input'}
    horafim = () => { return ':nth-child(3) > .MuiFormControl-root > .MuiInputBase-root > .MuiInputBase-input'}
    observacoes = () => { return ':nth-child(4) > .MuiFormControl-root > .MuiInputBase-root > .MuiInputBase-input'}
    botaocancelar = () => { return '.MuiButton-outlined > .MuiButton-label'}
    botaoregistraratividade = () => { return '.jss61 > .MuiButton-contained > .MuiButton-label'}
    encerrarAtividade = () => { return '.jss47 > .MuiIconButton-label > .MuiSvgIcon-root > path'}
}
export default ManterAtividadeElements;