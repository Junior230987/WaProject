class PortalUsuarioElements {
    //Locators do Portal do usuário
        registraratividade = () => { return '.MuiBox-root > .MuiButtonBase-root > .MuiButton-label'}
        setabotaoprojetos = () => { return '.MuiAutocomplete-popupIndicator > .MuiIconButton-label > .MuiSvgIcon-root'}
        tipoDeAcesso = () => { return '.d-none.d-md-inline' }
        prestadorDeServiço = () => { return '[href=""]' }
        pessoaFisica = () => { return '.has-treeview > .nav > :nth-child(1) > .nav-link' }
        veiculo = () => { return ':nth-child(2) > .nav-link' }
        empresa = () => { return ':nth-child(3) > .nav-link' }
          
    }
    export default PortalUsuarioElements;