class WALoginElements {
//Locators do Login de usuário

    botaoLogin = () => { return ':nth-child(1) > .MuiInputBase-root > .MuiInputBase-input'}
    emailInput = () => { return ':nth-child(1) > .MuiInputBase-root > .MuiInputBase-input'}
    emailobrInput = () => { return '.MuiFormHelperText-root'}
    senhaInput = () => { return ':nth-child(2) > .MuiInputBase-root > .MuiInputBase-input'}
    botaoEntrar = () => { return '.MuiButton-label'}
    esqueceusuaSenha = () => { 'a'}
    
}
export default WALoginElements;
