/* global Given, Then, When */
import LoginPage from '../../pageobjects/CredenciamentoPageObjects/LoginPageObjects'
import Dashboard from '../../pageobjects/CredenciamentoPageObjects/DashboardPageObjects';
const loginPage = new LoginPage
const dashboard = new Dashboard 

Given("acesso o site TimeSheet WaProject", () => {
    loginPage.acessarSite();
})

Then(/^preencher "([^"]*)" e "([^"]*)"$/, (email, Senha) => {
	loginPage.preencherUsuarioeSenha(email, Senha);
})

Then(/^O sistema apresenta "([^"]*)" ou "([^"]*)"$/, (tipoDeAcesso, mensagem) => {
	if (tipoDeAcesso) {
		dashboard.validarPerfil(tipoDeAcesso)
	}
	else {
		loginPage.validarMensagensLogin(mensagem)	
	}
});
